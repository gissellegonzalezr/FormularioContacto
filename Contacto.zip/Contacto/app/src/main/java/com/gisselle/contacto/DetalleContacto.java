package com.gisselle.contacto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class DetalleContacto extends AppCompatActivity {

        private TextView tvNombre;
        private TextView tvNacimiento;
        private TextView tvTelefono;
        private TextView tvEmail;
        private TextView tvDescripcion;
        private Button botonVolver;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_detalle__contacto);

                Bundle parametros = getIntent().getExtras();
                String nombre = parametros.getString("Nombre");
                String fechaNacimiento = parametros.getString("Nacimiento");
                String telefono = parametros.getString("Telefono");
                String mail = parametros.getString("Email");
                String descripcion = parametros.getString("Descripcion");

                tvNombre = (TextView) findViewById(R.id.tvNombre);
                tvNacimiento = (TextView) findViewById(R.id.tvFechaNacimiento);
                tvTelefono = (TextView) findViewById(R.id.tvTelefono);
                tvEmail = (TextView)findViewById(R.id.tvEmail);
                tvDescripcion = (TextView)findViewById(R.id.tvDescripcion);
                botonVolver = (Button) findViewById(R.id.btEditarDatos);


                tvNombre.setText("Nombre : " + nombre);
                tvNacimiento.setText("Fecha de Nacimiento : " + fechaNacimiento);
                tvTelefono.setText("Telefono : "+ telefono);
                tvEmail.setText("Email : " + mail);
                tvDescripcion.setText("Descripcion : " + descripcion);

                botonVolver.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                                onBackPressed();
                        }
                });

        }

        @Override
        public void onBackPressed() {
                super.onBackPressed();
        }
}